package model;

import model.interfaces.IShape;

import java.awt.*;
import java.awt.geom.Point2D;
import controller.ClickHandler;
public class ShapeFactory {




    private ShapeFactory(){}
        public  static IShape createShape(Point startPoint, Point endPoint, ShapeConfiguration shapeConfiguration){
            Shape shape =new Shape(startPoint, endPoint, shapeConfiguration);
            return shape;

        }
    }

