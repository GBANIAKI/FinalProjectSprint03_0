package model;
import model.MouseMode;

public class ShapeConfiguration {
    private ShapeType activeShapeType;
    private ShapeColor activePrimaryColor;
    private ShapeColor activeSecondaryColor;
    private ShapeShadingType activeShadingType;
    private MouseMode activeStartAndEndPointMode;
    public ShapeConfiguration(
            ShapeType activeShapeType,
    ShapeColor activePrimaryColor,
     ShapeColor activeSecondaryColor,
    ShapeShadingType activeShadingType,
    MouseMode activeStartAndEndPointMode) {
        this.activeShapeType= activeShapeType;
        this.activePrimaryColor=activePrimaryColor;
        this.activeSecondaryColor= activeSecondaryColor;
        this.activeShadingType=activeShadingType;
        this.activeStartAndEndPointMode= activeStartAndEndPointMode;

    }
    public ShapeType getActiveShapeType(){
        return activeShapeType;
    }
    public ShapeColor getActivePrimaryColor(){
        return activePrimaryColor;
    }
    public ShapeColor getActiveSecondaryColor(){
        return activeSecondaryColor;
    }
    public  ShapeShadingType getActiveShadingType(){
        return activeShadingType;
    }

    public  MouseMode getActiveMouseMode(){
        return activeStartAndEndPointMode;
    }
    public ShapeConfiguration deepCopy( ){
        return new ShapeConfiguration(this.activeShapeType,
                this.activePrimaryColor,
                this.activeSecondaryColor,
                this.activeShadingType,this.activeStartAndEndPointMode);
    }





}
