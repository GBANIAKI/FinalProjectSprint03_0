package model;

import model.interfaces.IShapeList;

public class ClipBoardShapeList extends ShapeList implements IShapeList {
    public ClipBoardShapeList(){
          super();
    }
}
