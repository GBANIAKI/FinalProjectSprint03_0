package model;

import model.interfaces.IDrawObserver;
import model.interfaces.IDrawShapeStrategy;
import model.interfaces.IDrawSubject;
import model.interfaces.IShape;

import java.util.ArrayList;

public class MasterShapeList implements IDrawSubject {
    private ArrayList<IShape> shapeList;

    private ArrayList<IDrawObserver> observers;
    public MasterShapeList(){
        //this.shapeList=new ShapeList();
        this.shapeList=new ArrayList<>();
        this.observers=new ArrayList<>();
    }
    public void add(IShape shape){
        this.shapeList.add(shape);
        this.notifyObserver();
    }
    public void remove(IShape shape){
        this.shapeList.remove(shape);
        this.notifyObserver();
    }
    public void shapeModified(){
        this.notifyObserver();

    }
    public void registerObserver(IDrawObserver observerDrawer){
        this.observers.add(observerDrawer);
    }
    public void removeObserver(IDrawObserver observerDrawer){
        this.observers.remove(observerDrawer);
    }
    public void notifyObserver(){
        for(IDrawObserver observer: this.observers){
            observer.update(this.shapeList);

        }
    }

    public ArrayList<IShape> getShapeList() {
        return this.shapeList;
    }
}
