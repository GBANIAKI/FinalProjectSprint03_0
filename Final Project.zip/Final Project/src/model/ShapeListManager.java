package model;

import model.interfaces.IShapeList;

public class ShapeListManager {
    private final MasterShapeList masterShapeList;
    private final IShapeList selectedShapeList;
    private IShapeList clipBoardShapeList;
    public ShapeListManager( MasterShapeList masterShapeList,
    IShapeList selectedShapeList,
    IShapeList clipBoardShapeList){
        this.masterShapeList= masterShapeList;
        this.selectedShapeList = selectedShapeList;
        this.clipBoardShapeList= clipBoardShapeList;
    }
     public MasterShapeList getMasterShapeList(){
        return this.masterShapeList;
    }
    public  IShapeList getSelectedShapeList(){
        return this.selectedShapeList;
    }
    public IShapeList getClipBoardShapeList(){
        return this.clipBoardShapeList;
    }
}
