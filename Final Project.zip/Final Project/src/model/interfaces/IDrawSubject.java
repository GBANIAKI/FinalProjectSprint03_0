package model.interfaces;

public interface IDrawSubject {
    public void registerObserver(IDrawObserver observerDrawer);
    public void removeObserver(IDrawObserver observerDrawer);
    public void notifyObserver();
}
