package commands;

import controller.ICommand;
import model.ShapeListManager;
import model.interfaces.IShape;
import model.interfaces.IShapeList;

public class CopyCommand implements ICommand {
    private IShapeList selectedShapeList;
    private IShapeList clipBoardShapeList;
    public CopyCommand(ShapeListManager shapeListManager){

        this.selectedShapeList= shapeListManager.getSelectedShapeList();
        this.clipBoardShapeList=shapeListManager.getClipBoardShapeList();
    }

    @Override
    public void run() {
        clipBoardShapeList.getShapeList().clear();
        for(IShape shape: selectedShapeList.getShapeList())
            clipBoardShapeList.add(shape);


    }
}
