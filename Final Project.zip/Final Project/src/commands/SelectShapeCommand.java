package commands;

import controller.ICommand;
import model.CollisionDetector;
import model.MasterShapeList;
import model.Point;
import model.ShapeListManager;
import model.interfaces.IShape;
import model.interfaces.IShapeList;

public class SelectShapeCommand implements ICommand {
    private MasterShapeList masterShapeList;
    private IShapeList selectedShapeList;
    private Point selectionStartPoint;
    private Point selectionEndPoint;
    public SelectShapeCommand(ShapeListManager shapeListManager,Point selectionStartPoint,
                              Point selectionEndPoint){
        this.masterShapeList = shapeListManager.getMasterShapeList();
        this.selectedShapeList= shapeListManager.getSelectedShapeList();
        this.selectionStartPoint= selectionStartPoint;
        this.selectionEndPoint= selectionEndPoint;
    }


    @Override
    public void run() {
        for(IShape shape: masterShapeList.getShapeList()){
            if(CollisionDetector.detectCollision(shape, selectionStartPoint, selectionEndPoint)){
                selectedShapeList.add(shape);
            }
        }

    }
}
