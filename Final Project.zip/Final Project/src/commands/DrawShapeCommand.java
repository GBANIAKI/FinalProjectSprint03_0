package commands;

import controller.ICommand;
import model.*;
import model.interfaces.IShape;
import model.interfaces.IShapeList;
import model.interfaces.IUndoable;
import model.persistence.ApplicationState;

import java.awt.geom.Point2D;

public class DrawShapeCommand implements ICommand, IUndoable{
    private MasterShapeList masterShapeList;
    private IShapeList selectedShapeList;
    private ApplicationState appState;
     private Point startPoint;
    private Point endPoint;
    private IShape LastShapeDrawn;
    public DrawShapeCommand(ShapeListManager shapeListManager, ApplicationState appState,
                            Point startPoint, Point endPoint){
        this.masterShapeList=shapeListManager.getMasterShapeList();
        this.selectedShapeList=shapeListManager.getSelectedShapeList();
        this.appState=appState;
        this.startPoint=startPoint;
        this.endPoint= endPoint;
        //this.LastShapeDrawn=stShapeDrawnLa;
    }


    public void run(){
        ShapeConfiguration shapeConfiguration= appState.getCurrentShapeConfiguration();
        IShape shape = ShapeFactory.createShape(this.startPoint, this.endPoint, shapeConfiguration);
        this.masterShapeList.add(shape);
        this.LastShapeDrawn=shape;
        CommandHistory.add(this);

    }
    public void undo(){
        this.masterShapeList.remove(this.LastShapeDrawn);
        System.out.println(masterShapeList);

        /*if(!this.selectedShapeList.getShapeList().isEmpty()){
            for(int i =0; i< this.selectedShapeList.getShapeList().size(); i++){
                if(this.selectedShapeList.getShapeList().get(i)==this.LastShapeDrawn){
                    this.selectedShapeList.getShapeList().remove(this.LastShapeDrawn);


                }
            }
        }*/

    }
    public void redo(){
        this.masterShapeList.add(this.LastShapeDrawn);
    }


}
