package controller;

import commands.*;
import model.MouseMode;
import model.ShapeListManager;
import model.interfaces.IApplicationState;
import model.Point;
import model.interfaces.IUndoable;
import model.persistence.ApplicationState;
import view.gui.PaintCanvas;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ClickHandler extends MouseAdapter {

    public Point startPoint;
    public  Point endPoint;
    private ApplicationState applicationState;
    private ShapeListManager shapeListManager;
     public ClickHandler(ApplicationState applicationState, ShapeListManager shapeListManager ){
         this.applicationState=applicationState;
         this.shapeListManager= shapeListManager;

     }

    @Override
    public void mousePressed(MouseEvent e) {

        this.startPoint= new Point(e.getX(),e.getY());

    }

    @Override
    public void mouseReleased(MouseEvent e) {


        this.endPoint= new Point(e.getX(),e.getY());
        Point topLeft = new Point(Integer.min(this.startPoint.getX(),this.endPoint.getX()),
                Integer.min(this.startPoint.getY(),this.endPoint.getY()));
        Point bottomRight = new Point(Integer.max(this.startPoint.getX(),this.endPoint.getX()),
                Integer.max(this.startPoint.getY(),this.endPoint.getY()));
        ICommand command;
        switch (applicationState.getActiveMouseMode()){
            case DRAW:
                command = new DrawShapeCommand(shapeListManager,applicationState,topLeft, bottomRight);

                break;
            case SELECT:
                shapeListManager.getSelectedShapeList().getShapeList().clear();
                command= new SelectShapeCommand(shapeListManager,topLeft,bottomRight);
                break;
            case MOVE:
                command= new MoveShapeCommand(shapeListManager,this.startPoint,this.endPoint);
                break;

            default:
                //command = new DrawShapeCommand(shapeListManager,applicationState,topLeft, bottomRight );
                throw new Error("error");
                //break;
        }

        command.run();


     }
}

