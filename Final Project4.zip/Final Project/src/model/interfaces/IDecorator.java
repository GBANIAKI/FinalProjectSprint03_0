package model.interfaces;

public interface IDecorator extends IDrawShapeStrategy{

}
