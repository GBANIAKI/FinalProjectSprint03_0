package commands;

public class UngroupCommand {

}
