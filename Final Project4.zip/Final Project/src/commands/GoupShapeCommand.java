package commands;

public class GoupShapeCommand {
}
