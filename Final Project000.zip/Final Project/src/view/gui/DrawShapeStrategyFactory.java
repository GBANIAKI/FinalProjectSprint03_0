package view.gui;

import model.interfaces.IDrawShapeStrategy;

public class DrawShapeStrategyFactory {
    public static IDrawShapeStrategy createDrawRectangleStrategy(){
        return new DrawRectangleStrategy();
    }
    public static IDrawShapeStrategy createDrawEllipseStrategy(){
        return new DrawEllipseStrategy();
    }
    public static IDrawShapeStrategy createDrawTriangleStrategy(){
        return new DrawTriangleStrategy();
    }
}
