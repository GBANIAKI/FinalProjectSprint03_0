package controller;

public interface ICommand {
    public void run();
}
