package commands;

public class PasteShapeCommand {
}
