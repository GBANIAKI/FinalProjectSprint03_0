package commands;

import controller.ICommand;
import model.CollisionDetector;
import model.MasterShapeList;
import model.Point;
import model.ShapeListManager;
import model.interfaces.IDrawSubject;
import model.interfaces.IShape;
import model.interfaces.IShapeList;
import model.interfaces.IShapeListManager;

public class SelectShapeCommand implements ICommand {
    private final IDrawSubject masterShapeList;
    private final IShapeList selectedShapeList;
    private final Point selectionStartPoint;
    private final Point selectionEndPoint;
    public SelectShapeCommand(IShapeListManager shapeListManager, Point selectionStartPoint,
                              Point selectionEndPoint){
        this.masterShapeList = shapeListManager.getMasterShapeList();
        this.selectedShapeList= shapeListManager.getSelectedShapeList();
        this.selectionStartPoint= selectionStartPoint;
        this.selectionEndPoint= selectionEndPoint;
    }


    @Override
    public void run() {
        for(IShape shape: masterShapeList.getShapeList()){
            if(CollisionDetector.detectCollision(shape, selectionStartPoint, selectionEndPoint)){
                selectedShapeList.add(shape);
            }
        }

    }
}
