package commands;

import controller.ICommand;
import model.MasterShapeList;
import model.interfaces.IShapeList;
import model.interfaces.IUndoable;

public class DeleteShapeCommand implements ICommand, IUndoable {


    @Override
    public void run() {

    }

    @Override
    public void undo() {

    }

    @Override
    public void redo() {

    }
}
