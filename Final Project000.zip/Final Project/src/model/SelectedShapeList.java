package model;

import model.interfaces.IShape;
import model.interfaces.IShapeList;

import java.util.ArrayList;

public class SelectedShapeList extends ShapeList implements IShapeList {
    public SelectedShapeList(){
        super();
    }
}
